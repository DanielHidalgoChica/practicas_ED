var searchData=
[
  ['operator_3d_16',['operator=',['../classImage.html#aeaa2d687caf48e3c72fc773c70a0e9fa',1,'Image']]],
  ['operator_3d_3d_17',['operator==',['../classImage.html#a8c8a8dd2b91db9438df71ec63c58414d',1,'Image']]]
];
