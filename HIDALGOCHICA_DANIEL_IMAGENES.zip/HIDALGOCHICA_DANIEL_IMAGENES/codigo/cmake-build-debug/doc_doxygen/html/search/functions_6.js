var searchData=
[
  ['mean_44',['Mean',['../classImage.html#a08ac7df75c7bc99da2b3abdc35719203',1,'Image']]]
];
