var searchData=
[
  ['save_49',['Save',['../classImage.html#adde1007dc6359087dae65fa8cae26448',1,'Image']]],
  ['set_5fpixel_50',['set_pixel',['../classImage.html#a6e316f867fd3b67a75d78ca66bc12195',1,'Image::set_pixel(int i, int j, byte value)'],['../classImage.html#adf54cab55e991b8fac7d8043507588cb',1,'Image::set_pixel(int k, byte value)']]],
  ['size_51',['size',['../classImage.html#a78068ea10fef9954ea0e91705997652d',1,'Image']]],
  ['subsample_52',['Subsample',['../classImage.html#aa00e596a67ec6130922c560049457985',1,'Image']]]
];
