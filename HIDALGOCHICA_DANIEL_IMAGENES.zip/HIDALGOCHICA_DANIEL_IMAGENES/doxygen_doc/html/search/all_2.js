var searchData=
[
  ['comparar_2ecpp_5',['comparar.cpp',['../comparar_8cpp.html',1,'']]],
  ['contraste_2ecpp_6',['contraste.cpp',['../contraste_8cpp.html',1,'']]],
  ['crop_7',['Crop',['../classImage.html#aad309b582d08dfd826c5106eaf80eb1e',1,'Image']]],
  ['crop_2ecpp_8',['crop.cpp',['../crop_8cpp.html',1,'']]]
];
