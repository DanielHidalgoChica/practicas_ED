var searchData=
[
  ['icono_2ecpp_15',['icono.cpp',['../icono_8cpp.html',1,'']]],
  ['image_16',['Image',['../classImage.html',1,'Image'],['../classImage.html#a58edd1c45b4faeb5f789b0d036d02313',1,'Image::Image()'],['../classImage.html#a24d6fed0a7c3dc53b86411dd68bfbb2e',1,'Image::Image(int nrows, int ncols, byte value=0)'],['../classImage.html#abda271aa11b907dda8c8c8176684227d',1,'Image::Image(const Image &amp;orig)']]],
  ['image_2ecpp_17',['image.cpp',['../image_8cpp.html',1,'']]],
  ['image_2eh_18',['image.h',['../image_8h.html',1,'']]],
  ['imageio_2ecpp_19',['imageIO.cpp',['../imageIO_8cpp.html',1,'']]],
  ['imageio_2eh_20',['imageIO.h',['../imageIO_8h.html',1,'']]],
  ['imagekind_21',['ImageKind',['../imageIO_8h.html#a18b6324755c82f3edc3da0a37066dc53',1,'imageIO.h']]],
  ['imageop_2ecpp_22',['imageop.cpp',['../imageop_8cpp.html',1,'']]],
  ['invert_23',['Invert',['../classImage.html#a6c9c1b3fef7795378f8a56fdd491ffa0',1,'Image']]]
];
