var searchData=
[
  ['load_24',['Load',['../classImage.html#a997e2d58be54bca2cf8f4da5818bf771',1,'Image']]],
  ['loadresult_25',['LoadResult',['../image_8h.html#abf07f72999ea5b856ced9c5fe0a64f70',1,'image.h']]]
];
