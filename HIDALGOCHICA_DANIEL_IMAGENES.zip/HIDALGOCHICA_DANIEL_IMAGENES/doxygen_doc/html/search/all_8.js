var searchData=
[
  ['mean_26',['Mean',['../classImage.html#a08ac7df75c7bc99da2b3abdc35719203',1,'Image']]],
  ['mysave_27',['MySave',['../classImage.html#abc118c5aead787742d56a3a750b5e790',1,'Image']]]
];
