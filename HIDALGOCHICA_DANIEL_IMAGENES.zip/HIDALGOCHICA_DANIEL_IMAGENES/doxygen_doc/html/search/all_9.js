var searchData=
[
  ['negativo_2ecpp_28',['negativo.cpp',['../negativo_8cpp.html',1,'']]]
];
