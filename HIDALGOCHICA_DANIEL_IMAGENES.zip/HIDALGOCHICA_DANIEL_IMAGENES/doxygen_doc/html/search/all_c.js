var searchData=
[
  ['save_34',['Save',['../classImage.html#adde1007dc6359087dae65fa8cae26448',1,'Image']]],
  ['set_5fpixel_35',['set_pixel',['../classImage.html#a6e316f867fd3b67a75d78ca66bc12195',1,'Image::set_pixel(int i, int j, byte value)'],['../classImage.html#adf54cab55e991b8fac7d8043507588cb',1,'Image::set_pixel(int k, byte value)']]],
  ['shufflerows_5feff_36',['ShuffleRows_eff',['../classImage.html#a697bec07fe363b64ad1b152a6df47a16',1,'Image']]],
  ['shufflerows_5fnoeff_37',['ShuffleRows_noeff',['../classImage.html#a1a3afd6887e6629eb841c6b66d14d9d2',1,'Image']]],
  ['size_38',['size',['../classImage.html#a78068ea10fef9954ea0e91705997652d',1,'Image']]],
  ['subsample_39',['Subsample',['../classImage.html#aa00e596a67ec6130922c560049457985',1,'Image']]]
];
