var searchData=
[
  ['loadresult_85',['LoadResult',['../image_8h.html#abf07f72999ea5b856ced9c5fe0a64f70',1,'image.h']]]
];
