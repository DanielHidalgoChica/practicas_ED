var searchData=
[
  ['comparar_2ecpp_48',['comparar.cpp',['../comparar_8cpp.html',1,'']]],
  ['contraste_2ecpp_49',['contraste.cpp',['../contraste_8cpp.html',1,'']]],
  ['crop_2ecpp_50',['crop.cpp',['../crop_8cpp.html',1,'']]]
];
