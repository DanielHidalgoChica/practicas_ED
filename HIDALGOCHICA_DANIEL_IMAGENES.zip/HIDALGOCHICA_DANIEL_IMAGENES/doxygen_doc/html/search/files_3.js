var searchData=
[
  ['negativo_2ecpp_57',['negativo.cpp',['../negativo_8cpp.html',1,'']]]
];
