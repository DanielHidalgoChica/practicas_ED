var searchData=
[
  ['operator_3d_70',['operator=',['../classImage.html#aeaa2d687caf48e3c72fc773c70a0e9fa',1,'Image']]],
  ['operator_3d_3d_71',['operator==',['../classImage.html#a65865b76fd2a4273fd0c7e14b75e8549',1,'Image']]]
];
