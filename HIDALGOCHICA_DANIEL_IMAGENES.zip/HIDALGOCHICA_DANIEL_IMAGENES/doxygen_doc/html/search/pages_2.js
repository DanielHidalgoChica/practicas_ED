var searchData=
[
  ['representación_20del_20tda_20imagen_88',['Representación del TDA Imagen',['../page_repImagen.html',1,'']]]
];
