var indexSectionsWithContent =
{
  0: "abcdegilmnorswz~",
  1: "i",
  2: "bcinz",
  3: "acegilmorswz~",
  4: "b",
  5: "il",
  6: "der"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "enums",
  6: "pages"
};

var indexSectionLabels =
{
  0: "Todo",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "typedefs",
  5: "Enumeraciones",
  6: "Páginas"
};

